import myModule

print(myModule.fib(10))
print(myModule.version())
